
install.packages("tidyverse")
install.packages("factoextra")
install.packages("cowplot")
install.packages("ggpubr")
install.packages("cluster")
install.packages("textshape")
install.packages("ggplot2")

library(tidyverse)
library(factoextra)
library(cowplot)
library(ggpubr)
library(cluster)
library(textshape)
library(readxl)
library(ggplot2)

#:::::::::::::::::::::An�lisis de cluster no jerarquico:::::::::::::::::::


# Escalar y centrar las variables: media=0 y sd= 1 

df<-as.data.frame(Data_R)

df<-textshape::column_to_rownames(df, loc = 1)


View(df)
?df
summary(df)


df_scaled= scale(df, center = TRUE, scale = TRUE)
summary(df_scaled)

Cluster_Wilches=as.data.frame(df_scaled)

#creamos 5 cluster 

kmcluster = kmeans(Cluster_Wilches,centers=5,nstart = 50)
kmcluster

#graficamos los cluster en funcion de Ca y Cl

Cluster_Wilches = Cluster_Wilches %>% mutate(cluster = kmcluster$cluster)

(g1=ggplot(Cluster_Wilches, aes(x = Ca, y = Cl)) +
  geom_point(aes(color=as.factor(cluster)), size=10)+
  geom_text(aes(label = cluster), size = 5) +
  theme_bw() +
  theme(legend.position = "none")+
  labs(title = "Kmenas con k=5") 
)

#graficamos sus 2 primeras componentes

fviz_cluster(kmcluster, Cluster_Wilches)+
  theme_minimal()



fviz_cluster(kmcluster, inseguridad, show.clust.cent = T,
             ellipse.type = "euclid", star.plot = T, repel = T) +
  labs(title = "Resultados clustering K-means") +
  theme_bw()
 

#### Creamos 2 cluster k=2
kmcluster2 = kmeans(inseguridad, centers=2, nstart = 50)
inseguridad = inseguridad %>% mutate(cluster2 = kmcluster2$cluster)

(g2=ggplot(inseguridad, aes(x = Murder, y = Assault)) +
  geom_point(aes(color=as.factor(cluster2)), size=10)+
  geom_text(aes(label = cluster2), size = 5) +
  theme_bw() +
  theme(legend.position = "none")+
  labs(title = "Kmenas con k=2") 
)

plot_grid(g1,g2)


#::::::::::::::: N�mero �ptimo de Cluster  :::::::::::::::



matriz_dist=get_dist(df, method = "euclidean")

fviz_nbclust(df, FUNcluster = kmeans, 
             method = "wss", k.max = 15, 
             diss = matriz_dist, nstart = 50)

#::::::::::::::: De acuerdo a lo anterior, el n�mero �ptimo de cluster es 3, ya que la varianza entre 3 y 4 no es significativa :::::::::::::::

#creamos 3 cluster 

kmcluster = kmeans(Cluster_Wilches,centers=3,nstart = 50)
kmcluster

#graficamos los cluster en funcion de Ca y Cl

Cluster_Wilches = Cluster_Wilches %>% mutate(cluster = kmcluster$cluster)

(g1=ggplot(Cluster_Wilches, aes(x = HCO3, y = Ca)) +
    geom_point(aes(color=as.factor(cluster)), size=10)+
    geom_text(aes(label = cluster), size = 5) +
    theme_bw() +
    theme(legend.position = "none")+
    labs(title = "Kmenas con k=3") 
)

#graficamos sus 2 primeras componentes

fviz_cluster(kmcluster, Cluster_Wilches)+
  theme_minimal()

#::::::::::::::::::::::::::Cluster jerarquico:::::::::::::::::::::::::::::
 
Euclid <- dist(Cluster_PTO_Wilches, method = "euclidean")
Euclid

hierarchical <- hclust(Euclid, method="ward.D")
hierarchical

plot(hierarchical, labels = Muestra)
rect.hclust(hierarchical, k=3, border = "red")


ClusJ <- hclust(dist(df), method = "ward.D2")
plot(ClusJ)  

rect.hclust(ClusJ, k=3, border = "magenta")

#:::::::::::::::::AN�LISIS DE PCA::::::::::::::::::::::
library (dplyr)
library(statsr)
library(readxl)

base_datos <- Data_R
View(base_datos)

base_datos<-textshape::column_to_rownames(base_datos, loc = 1)

df_pca<-as.data.frame(base_datos)

respca<-prcomp(df_pca, scale = TRUE)

names(respca)

head(respca$rotation)[, 1:8] 

dim(respca$rotation) 

head(respca$x)[,1:8]

respca$sdev 

respca$sdev^2  

summary(respca)

xx<-respca$x
xx<-as.data.frame(xx)
base_datos$PC1<-xx$PC1
base_datos$PC2<-xx$PC2
head(base_datos)
cor(base_datos)

install.packages("factoextra")
library(factoextra)
install.packages("FactoMineR")
library(FactoMineR)
library(stats)


respca2 <- PCA(X = df_pca, scale.unit = TRUE, ncp = 8, graph = TRUE)
head(respca2$eig)

get_pca(respca2) 

get_pca_var(respca2) 

get_pca_ind(respca2) 

fviz_pca_ind(respca2)

fviz_pca_ind(respca2,
             col.ind = "cos2", # Color by the quality of representation
             gradient.cols = c("#00AFBB", "#E7B800", "#FC4E07"),
             repel = FALSE     # Avoid text overlapping
)

fviz_pca_var(respca2,
             col.var = "contrib", # Color by contributions to the PC
             gradient.cols = c("#00AFBB", "#E7B800", "#FC4E07"),
             repel = TRUE     # Avoid text overlapping
)


