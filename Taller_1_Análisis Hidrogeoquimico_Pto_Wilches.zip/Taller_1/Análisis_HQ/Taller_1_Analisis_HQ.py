import os
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from sklearn.preprocessing import StandardScaler



df = pd.read_excel(r'Dtaller1.xlsx', index_col=None, header=0)
from wqchartpy import triangle_piper

from wqchartpy import gibbs

gibbs.plot(df, unit='mg/L', figname='Gibbs diagram', figformat='jpg')

from wqchartpy import triangle_piper

triangle_piper.plot(df, unit='mg/L', figname='triangle Piper diagram', figformat='jpg')


# Show the df
df

df.loc[:, 'Size'] = 0.1 *  df.loc[:, 'TDS']
df.loc[:, 'Color'] = 1 * df.loc[:, 'TDS']
from wqchartpy import triangle_piper

triangle_piper.plot(df, unit='mg/L', figname='triangle Piper diagram', figformat='jpg')

from wqchartpy import hfed

hfed.plot(df, unit='mg/L', figname='triangle Piper diagram', figformat='jpg')


from wqchartpy import schoeller
schoeller.plot(df, unit='mg/L', figname='Schoeller diagram', figformat='jpg') 

from wqchartpy import gaillardet
gaillardet.plot(df, unit='mg/L', figname='Gaillardet diagram', figformat='jpg')


from wqchartpy import chadha
chadha.plot(df, unit='mg/L', figname='Chadha diagram', figformat='jpg')

from wqchartpy import stiff
stiff.plot(df, unit='mg/L', figname='Stiff diagram', figformat='jpg')